import CertificationsSection from "../sections/CertificationsSection";

export default function CertificationsSectionExample() {
  return <CertificationsSection />;
}
