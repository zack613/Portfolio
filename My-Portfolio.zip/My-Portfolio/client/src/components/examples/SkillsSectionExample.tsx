import SkillsSection from "../sections/SkillsSection";

export default function SkillsSectionExample() {
  return <SkillsSection />;
}
