import AboutSection from "../sections/AboutSection";

export default function AboutSectionExample() {
  return <AboutSection />;
}
