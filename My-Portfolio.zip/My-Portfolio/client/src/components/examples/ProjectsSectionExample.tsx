import ProjectsSection from "../sections/ProjectsSection";

export default function ProjectsSectionExample() {
  return <ProjectsSection />;
}
