import EducationSection from "../sections/EducationSection";

export default function EducationSectionExample() {
  return <EducationSection />;
}
