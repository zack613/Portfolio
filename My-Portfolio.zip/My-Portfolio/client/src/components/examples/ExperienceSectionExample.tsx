import ExperienceSection from "../sections/ExperienceSection";

export default function ExperienceSectionExample() {
  return <ExperienceSection />;
}
